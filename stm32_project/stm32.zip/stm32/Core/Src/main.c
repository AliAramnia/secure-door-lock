/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define printf_debug            1
#if printf_debug
    #define DEBUG_PRINT(fmt, ...) printf(fmt, ##__VA_ARGS__)
#else
    #define DEBUG_PRINT(fmt, ...)
#endif
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "cmox_crypto.h"
#include "MY_FLASH.h"
#define PCF8591 (0x48<<1)
#define ADC3 0x03
uint8_t read_ADC3_value(I2C_HandleTypeDef *hi2c);
uint8_t mapToRange(uint8_t value);
void displayOnLEDs(uint8_t value);
void sha256(uint8_t *data,uint8_t *result,uint8_t DataSize);
bool Read_btn();
void enrollment();
bool unlock();
uint8_t password[8];
uint8_t saved_password[32];
void UART2_Init(void);
uint8_t UART2_ReceiveByte(void);
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef hcrc;

I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_CRC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int _write(int file, char *ptr, int len){
  (void)file;
  int DataIdx;

  for (DataIdx = 0; DataIdx < len; DataIdx++)
  {
    ITM_SendChar(*ptr++);
  }
  return len;
}
void I2C_Scan() {
  printf("Scanning I2C bus...\n");

  for (uint8_t i = 1; i < 128; i++) {  // I2C addresses range from 1 to 127
    if (HAL_I2C_IsDeviceReady(&hi2c1, (i << 1), 1, HAL_MAX_DELAY) == HAL_OK) {
      DEBUG_PRINT("Device found at 0x%02X\n", i);
    }
  }

  DEBUG_PRINT("Scan complete.\n");
}
void printArray(const char *arrayName, uint8_t *array, size_t size) {
    DEBUG_PRINT("%s: ", arrayName);
    for (size_t i = 0; i < size; i++) {
      DEBUG_PRINT("0x%02X ", array[i]);
    }
    DEBUG_PRINT("\n");
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_CRC_Init();
  /* USER CODE BEGIN 2 */
  UART2_Init();
  HAL_GPIO_WritePin(builtIn_led_GPIO_Port, builtIn_led_Pin, 1);
  DEBUG_PRINT("Hello world...\n");
  enrollment();
  DEBUG_PRINT("enrollment is done\n");
  page_read(saved_password,sizeof(saved_password));
  //printArray("saved_password",saved_password,sizeof(saved_password));

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    if (unlock()){
      HAL_GPIO_WritePin(builtIn_led_GPIO_Port, builtIn_led_Pin, 0);
      DEBUG_PRINT("correct\n");
    }else{
      DEBUG_PRINT("wrong\n");
      HAL_GPIO_WritePin(builtIn_led_GPIO_Port, builtIn_led_Pin, 1);
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(builtIn_led_GPIO_Port, builtIn_led_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Bit0_Pin|Bit1_Pin|Bit2_Pin|Bit3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Relay_Pin|send_data_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : builtIn_led_Pin */
  GPIO_InitStruct.Pin = builtIn_led_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(builtIn_led_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit0_Pin Bit1_Pin Bit2_Pin Bit3_Pin */
  GPIO_InitStruct.Pin = Bit0_Pin|Bit1_Pin|Bit2_Pin|Bit3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : Relay_Pin send_data_Pin */
  GPIO_InitStruct.Pin = Relay_Pin|send_data_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : btn_Pin */
  GPIO_InitStruct.Pin = btn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(btn_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
uint8_t read_ADC3_value(I2C_HandleTypeDef *hi2c) {
    uint8_t control_byte = ADC3;
    uint8_t data[2] = {0};

    // Begin transmission (wake up PCF8591 and set control byte)
    if (HAL_I2C_Master_Transmit(hi2c, PCF8591, &control_byte, 1, HAL_MAX_DELAY) != HAL_OK) {
        // Transmission error handling
        return 0;
    }

    // Request 2 bytes from the device
    if (HAL_I2C_Master_Receive(hi2c, PCF8591, data, 2, HAL_MAX_DELAY) != HAL_OK) {
        // Reception error handling
        return 0;
    }

    // Read the second byte as the ADC3 value
    return data[1];
}

uint8_t mapToRange(uint8_t value) {
    return value / 16;
}

// Function to display a 4-bit value on 4 LEDs
void displayOnLEDs(uint8_t value) {
    // Set or reset each LED based on the respective bit in `value`
    HAL_GPIO_WritePin(Bit0_GPIO_Port, Bit0_Pin, (value & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(Bit1_GPIO_Port, Bit1_Pin, (value & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(Bit2_GPIO_Port, Bit2_Pin, (value & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(Bit3_GPIO_Port, Bit3_Pin, (value & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void sha256(uint8_t *data,uint8_t *result,uint8_t DataSize){
  size_t computed_size;
    cmox_hash_compute(CMOX_SHA256_ALGO,                /* Use SHA256 algorithm */
                 data, DataSize,           /* Message to digest */
               result,                   /* Data buffer to receive digest data */
               CMOX_SHA256_SIZE,         /* Expected digest size */
               &computed_size);          /* Size of computed digest */
}


bool Read_btn(){
  HAL_Delay(5);
  return HAL_GPIO_ReadPin(btn_GPIO_Port, btn_Pin);
}


void enrollment(){
  uint8_t index = 0;
  bool flag = true;
  while(1){
    uint8_t value = read_ADC3_value(&hi2c1);
    value = mapToRange(value);
    displayOnLEDs(value);
    if (Read_btn() == 1 && flag == true){
      flag = false;
      password[index] = value;
      index++;
    }
    if (Read_btn() == 0 && flag == false){
      flag = true;
    }
    if(index == 8){
      HAL_GPIO_WritePin(send_data_GPIO_Port, send_data_Pin, 1);
      uint8_t salt = UART2_ReceiveByte();
      DEBUG_PRINT("salt %02x\n",salt);
      HAL_GPIO_WritePin(send_data_GPIO_Port, send_data_Pin, 0);
//      if ( HAL_UART_Receive(&huart2, &salt, 1, 10) == HAL_OK){
//        DEBUG_PRINT("salt %02x\n",salt);
//        HAL_GPIO_WritePin(send_data_GPIO_Port, send_data_Pin, 0);
//      }
      printArray("password", password, sizeof(password));
      uint8_t temp_passwrod[9];
      temp_passwrod[0] = salt;
      for (int i =0;i<8;i++){
        temp_passwrod[i+1] = password[i];
      }
      printArray("temp_passwrod", temp_passwrod, sizeof(temp_passwrod));
      uint8_t computedSha256[32];
      sha256(temp_passwrod, computedSha256, sizeof(temp_passwrod));
      printArray("computedSha256", computedSha256, sizeof(computedSha256));
      page_write(computedSha256,sizeof(computedSha256));
      break;
    }
  }
}


bool unlock(){
  uint8_t index = 0;
  bool flag = true;
  while(1){
    uint8_t value = read_ADC3_value(&hi2c1);
    value = mapToRange(value);
    displayOnLEDs(value);
    if (Read_btn() == 1 && flag == true){
      flag = false;
      password[index] = value;
      index++;
    }
    if (Read_btn() == 0 && flag == false){
      flag = true;
    }
    if(index == 8){
      HAL_GPIO_WritePin(send_data_GPIO_Port, send_data_Pin, 1);
      uint8_t salt = UART2_ReceiveByte();
      DEBUG_PRINT("salt %02x\n",salt);
      HAL_GPIO_WritePin(send_data_GPIO_Port, send_data_Pin, 0);
//      uint8_t salt;
//      if ( HAL_UART_Receive(&huart2, &salt, 1, 10) == HAL_OK){
//        DEBUG_PRINT("salt %02x\n",salt);
//        HAL_GPIO_WritePin(send_data_GPIO_Port, send_data_Pin, 0);
//      }
      printArray("password", password, sizeof(password));
      uint8_t temp_passwrod[9];
      temp_passwrod[0] = salt;
      for (int i =0;i<8;i++){
        temp_passwrod[i+1] = password[i];
      }
      printArray("temp_passwrod", temp_passwrod, sizeof(temp_passwrod));
      uint8_t computedSha256[32];
      sha256(temp_passwrod, computedSha256, sizeof(temp_passwrod));
      printArray("computedSha256", computedSha256, sizeof(computedSha256));
      for (int i = 0; i < 32; i++) {
          if (computedSha256[i] != saved_password[i]) {
              return false;  // Arrays are not equal
          }
      }
      return true;
    }
  }
}


void UART2_Init(void) {
  // Enable clocks for USART2 and GPIOA
  RCC->APB1ENR |= RCC_APB1ENR_USART2EN;  // Enable USART2 clock
  RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;   // Enable GPIOA clock

  // Configure PA2 (TX) as alternate function push-pull
  GPIOA->CRL &= ~GPIO_CRL_CNF2;         // Clear CNF2[1:0] bits
  GPIOA->CRL |= GPIO_CRL_CNF2_1;        // Set CNF2[1:0] to 10 (AF push-pull)
  GPIOA->CRL |= GPIO_CRL_MODE2;         // Set MODE2[1:0] to 11 (output 50 MHz)

  // Configure PA3 (RX) as input floating
  GPIOA->CRL &= ~GPIO_CRL_CNF3;         // Clear CNF3[1:0] bits
  GPIOA->CRL |= GPIO_CRL_CNF3_0;        // Set CNF3[1:0] to 01 (input floating)
  GPIOA->CRL &= ~GPIO_CRL_MODE3;        // Set MODE3[1:0] to 00 (input mode)

  // Configure USART2
  USART2->BRR = 138;                 // Set baud rate to 115200 (assuming 16 MHz APB1 clock)
  USART2->CR1 |= USART_CR1_M;           // Set word length to 9 bits
  USART2->CR1 |= USART_CR1_PCE;         // Enable parity control
  USART2->CR1 &= ~USART_CR1_PS;         // Set even parity
  USART2->CR2 &= ~USART_CR2_STOP;       // Set 1 stop bit
  USART2->CR1 |= USART_CR1_TE | USART_CR1_RE; // Enable transmitter and receiver
  USART2->CR1 |= USART_CR1_UE;          // Enable USART2

  // Wait for the USART2 to be ready
  while (!(USART2->SR & USART_SR_TC));  // Wait for transmission complete flag
}

uint8_t UART2_ReceiveByte(void) {
    // Wait until the RXNE flag is set (data is available)
    while (!(USART2->SR & USART_SR_RXNE)) {
        // Wait for data to be received
    }

    // Read the received byte from the DR (Data Register)
    return (uint8_t)(USART2->DR & 0xFF); // Mask out the other bits and return only the received byte
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
