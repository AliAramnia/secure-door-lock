#include "MY_FLASH.h"

#define page_address 0x08007C00

void page_erase(void)
{
	HAL_FLASH_Unlock();
	FLASH_EraseInitTypeDef erasedef;
	erasedef.PageAddress = page_address;
	erasedef.NbPages = 1;
	erasedef.TypeErase = FLASH_TYPEERASE_PAGES;
	uint32_t pagerror;
	HAL_FLASHEx_Erase(&erasedef, &pagerror);
	HAL_FLASH_Lock();
}


void page_write(uint8_t *wrBuf, uint32_t Nsize)
{
	//Erase sector before write
  page_erase();
	//Unlock Flash
	HAL_FLASH_Unlock();
	//Write to Flash
	int flashAddress = page_address;
  for(uint32_t i=0; i<Nsize; i++)
  {
    HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, flashAddress , wrBuf[i]);
    flashAddress+=2;
  }
	//Lock the Flash space
	HAL_FLASH_Lock();
}

void page_read(uint8_t *rdBuf, uint32_t Nsize)
{
  int flashAddress = page_address;
  for(uint32_t i=0; i<Nsize; i++)
  {
    *((uint8_t *)rdBuf + i) = *(uint8_t *)flashAddress;
    flashAddress+=2;
  }
}
