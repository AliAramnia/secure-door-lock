#include "stm32f1xx_hal.h"



void page_erase(void);
void page_write(uint8_t *wrBuf, uint32_t Nsize);
void page_read(uint8_t *rdBuf, uint32_t Nsize);
